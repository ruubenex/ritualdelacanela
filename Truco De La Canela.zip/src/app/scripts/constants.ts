export const constants = {
    /**
     * Settings
     */
    Settings: {},
    /**
     * Push Notification settings.
     * @property {boolean} badge       - If badge enabled for push
     * @property {boolean} alert       - If alert enabled for push
     * @property {boolean} sound       - If sound enabled for push
     * @property {string} senderID     - Sender Id for android devices
     * @property {string} url          - URL of Apperyio push rest service
     * @property {string} guid         - Project GUID
     */
    PushNotification: {
        ios: {
            badge: true,
            alert: true,
            sound: true,
            clearBadge: true
        },
        android: {
            senderID: null
        },
        url: "https://api.appery.io/rest/push/reg",
        guid: "398d47b8-46dd-411c-a926-6bb0b17c6e74"
    }
};
export const routes = {
    "Screen1": "screen1",
    "Login1": "login1",
    "Screen1_31445": "screen1",
};
export const pushSettings = {
    appID: '398d47b8-46dd-411c-a926-6bb0b17c6e74',
    baseUrl: 'https://api.appery.io/rest/push/reg',
    baseSendUrl: 'https://api.appery.io/rest/push/msg',
    initOptions: {
        ios: {
            alert: true,
            badge: true,
            sound: true,
            clearBadge: true
        },
        android: {
            senderID: ''
        }
    }
};
export const projectInfo = {
    guid: '398d47b8-46dd-411c-a926-6bb0b17c6e74',
    name: 'Truco De La Canela',
    description: ''
};
export const pwaInfo = {
    name: 'Truco De La Canela',
    shortName: 'Truco De La Canela',
    description: '',
    icon: 'assets/images/appery512.png'
};
export const IGNORED_VALUE = Symbol.for("AIO_REST_IGNORED_VALUE");
export const apiHost = "https://api.appery.io";
export const defaultProxy = "";