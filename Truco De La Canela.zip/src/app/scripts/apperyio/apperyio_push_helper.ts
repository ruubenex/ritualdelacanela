import {
    Injectable,
    NgZone
} from '@angular/core';
import {
    checkAvailability
} from '@ionic-native/core';
import {
    Push,
    PushObject,
    PushOptions
} from '@ionic-native/push/ngx';
import {
    Platform
} from '@ionic/angular';
import {
    HttpClient,
    HttpParams,
    HttpHeaders,
    HttpErrorResponse
} from '@angular/common/http';
import {
    catchError
} from 'rxjs/operators';
import {
    throwError
} from 'rxjs';
import {
    Device
} from '@ionic-native/device/ngx';
import {
    pushSettings
} from '../constants';
const NOTIFICATION = "notification";
const ERROR = "error";
const REGISTER = "register";
const INIT = "init";
const DEVICE_END_POINT_URL = pushSettings.baseUrl;
const SEND_END_POINT_URL = pushSettings.baseSendUrl;
const APP_ID = pushSettings.appID;
@Injectable()
export class ApperyioPushHelperService {
    private deviceToken: string;
    private pushObject: PushObject;
    private uuid: string;
    private httpOptions;
    private registerUrl = "";
    private updateUrl = "";
    private unregisterUrl = "";
    private callbacks = {
        [NOTIFICATION]: [],
        [ERROR]: [],
        [REGISTER]: [],
        [INIT]: []
    }
    constructor(private push: Push, private http: HttpClient, private device: Device, private platform: Platform, private ngZone: NgZone) {
        const commonHttpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'X-Appery-App-ID': APP_ID
            })
        };
        this.setCommonHttpOptions(commonHttpOptions);
    }
    setCommonHttpOptions(commonHttpOptions) {
        this.httpOptions = commonHttpOptions;
    }
    setRegisterUrl(url?) {
        this.registerUrl = url;
    }
    setUpdateUrl(url?) {
        this.updateUrl = url;
    }
    setUnregisterUrl(url?) {
        this.unregisterUrl = url;
    }
    getRegisterUrl() {
        return this.registerUrl? this.registerUrl: this.getDeviceRegisterUrl();
    }
    getUpdateUrl(uuid?) {
        return this.updateUrl? this.updateUrl: this.getDeviceUrl(uuid || this._getUuid());
    }
    getUnregisterUrl(uuid?) {
        return this.unregisterUrl? this.unregisterUrl: this.getDeviceUrl(uuid || this._getUuid());
    }
    private getDeviceRegisterUrl() {
        return DEVICE_END_POINT_URL;
    }
    private getDeviceUrl(uuid) {
        return DEVICE_END_POINT_URL + '/' + uuid;
    }
    private getChannelUrl(uuid) {
        return DEVICE_END_POINT_URL + '/' + uuid + "/channel/";
    }
    private getSendPushUrl() {
        return SEND_END_POINT_URL;
    }
    private _execCallbacks(eventName: string, ...args) {
        let callbacks = this.callbacks[eventName];
        callbacks && callbacks.length && callbacks.forEach && this.ngZone.run(() => {
            callbacks.forEach(cb => cb.apply(null, args));
        });
    }
    private _getTimeZone() {
        let offset = new Date().getTimezoneOffset();
        let hr = offset / (-60);
        let min = -offset - hr * 60;
        let tmin = '' + min;
        let timezone = 'UTC' + (hr > 0? '+' + hr: hr) + ':' + (tmin.length > 1? tmin: '0' + tmin);
        return timezone;
    }
    on(eventName, callback): ApperyioPushHelperService {
        if (this.callbacks[eventName]) {
            this.callbacks[eventName].push(callback);
        }
        return this;
    }
    off(eventName, callback?): ApperyioPushHelperService {
        if (this.callbacks[eventName]) {
            if (callback === undefined) {
                this.callbacks[eventName] = [];
                return this;
            }
            const index = this.callbacks[eventName].indexOf(callback);
            if (index !== -1) {
                this.callbacks[eventName].splice(index, 1);
            }
        }
        return this;
    }
    init(options?, registerOptions?) {
        if (this.pushObject) return;
        this.platform.ready().then(() => {
            const isPushPluginEnabled = checkAvailability(this.push);
            if (isPushPluginEnabled && !( < any > isPushPluginEnabled).error) {
                if (this.pushObject) return;
                console.log('We have permission to send push notifications');
                const initOpts: PushOptions = pushSettings.initOptions;
                let initOptions = {};
                if (!options) {
                    options = {};
                }
                ["ios", "android", "windows", "browser"].forEach(name => {
                    if (initOpts[name] || options[name]) {
                        initOptions[name] = { ...initOpts[name],
                            ...options[name]
                        }
                    }
                });
                this.pushObject = this.push.init(initOptions);
                this.pushObject.on('notification').subscribe((notification: any) => {
                    this._execCallbacks(NOTIFICATION, notification);
                });
                this.pushObject.on('registration').subscribe((registration: any) => {
                    console.log('Device registered', registration);
                    this.deviceToken = registration.registrationId;
                    this._execCallbacks(INIT, registration);
                    this.register(registerOptions);
                });
                this.pushObject.on('error').subscribe(error => {
                    console.error('Error with Push plugin', error)
                });
            }
        });
    }
    register(options: any = {}, otherArgs: any = {}) {
        const observer = otherArgs.observer;
        const mockData: boolean = otherArgs.mockData;
        if (( < any > window).cordova) {
            let device = this.device;
            if (device) {
                let deviceType = (device.platform === 'iOS')?
                'I': 'A';
                const uuid = this._getUuid(options.deviceID);
                if (deviceType && uuid && this.deviceToken) {
                    let params = {
                        'type': deviceType,
                        'deviceID': uuid,
                        'token': this.deviceToken,
                        'timeZone': this._getTimeZone()
                    };
                    this.http.post(this.getRegisterUrl(), { ...params,
                            ...options
                        }, this.httpOptions)
                        .pipe(
                            catchError((error: HttpErrorResponse) => this.handleError(error))
                        )
                        .subscribe(res => this._execCallbacks(REGISTER, res));
                }
            }
        } else if (mockData && observer) {
            // For preview
            let params = {
                'type': 'I',
                'deviceID': "test_device",
                'token': "test_token",
                'timeZone': "GMT"
            };
            this.http.post(this.getRegisterUrl(), { ...params,
                    ...options
                }, this.httpOptions)
                .pipe(
                    catchError((error: HttpErrorResponse) => this.handleError(error, observer))
                )
                .subscribe(res => observer.next(res));
        }
    }
    private _getUuid(deviceID?) {
        if (deviceID) {
            return deviceID;
        }
        let device = this.device;
        if (device) {
            return device.uuid;
        }
    }
    unregister(options: any = {}, otherArgs: any = {}) {
        const observer = otherArgs.observer;
        const mockData: boolean = otherArgs.mockData;
        let uuid = this._getUuid(options.deviceID);
        if (!uuid && mockData) {
            uuid = "test_device";
        }
        if (uuid) {
            this.http.delete(this.getUnregisterUrl(uuid), this.httpOptions)
                .pipe(
                    catchError((error: HttpErrorResponse) => this.handleError(error, observer))
                )
                .subscribe(res => {
                    console.log(uuid + " unregistred");
                    if (observer) {
                        observer.next({
                            "deviceID": uuid
                        });
                    }
                });
        }
    }
    getDeviceInfo(options: any = {}, otherArgs: any = {}) {
        const observer = otherArgs.observer;
        const mockData: boolean = otherArgs.mockData;
        let uuid = this._getUuid(options.deviceID);
        if (!uuid && mockData) {
            uuid = "test_device";
        }
        if (uuid) {
            this.http.get(this.getDeviceUrl(uuid), this.httpOptions)
                .pipe(
                    catchError((error: HttpErrorResponse) => this.handleError(error, observer))
                )
                .subscribe(res => {
                    if (observer) {
                        observer.next(res);
                    }
                });
        }
    }
    update(options: any = {}, otherArgs: any = {}) {
        const observer = otherArgs.observer;
        const mockData: boolean = otherArgs.mockData;
        let uuid = this._getUuid(options.deviceID);
        if (!uuid && mockData) {
            uuid = "test_device";
        }
        if (uuid) {
            this.http.put(this.getUpdateUrl(uuid), options, this.httpOptions)
                .pipe(
                    catchError((error: HttpErrorResponse) => this.handleError(error))
                )
                .subscribe(res => {
                    if (observer) {
                        observer.next(res);
                    } else {
                        this._execCallbacks(REGISTER, res);
                    }
                    console.log(uuid + " updated");
                });
        }
    }
    _getDeviceId(options: any = {}, otherArgs: any = {}) {
        const observer = otherArgs.observer;
        const mockData: boolean = otherArgs.mockData;
        let uuid = this._getUuid(options.deviceID);
        if (!uuid && mockData) {
            uuid = "test_device";
        }
        if (observer) {
            if (uuid) {
                observer.next({
                    "deviceID": uuid
                });
            } else {
                observer.error("Can't define deviceID, check if PushPlugin is enabled");
            }
        }
    }
    _addDeviceToChannel(options: any = {}, otherArgs: any = {}) {
        const observer = otherArgs.observer;
        const mockData: boolean = otherArgs.mockData;
        const channel = options.channel;
        let uuid = this._getUuid(options.deviceID);
        if (!uuid && mockData) {
            uuid = "test_device";
        }
        if (observer) {
            this.http.put(this.getChannelUrl(uuid) + channel, {}, this.httpOptions)
                .pipe(
                    catchError((error: HttpErrorResponse) => this.handleError(error))
                )
                .subscribe(res => {
                    if (observer) {
                        observer.next(res);
                    }
                });
        }
    }
    _removeDeviceFromChannel(options: any = {}, otherArgs: any = {}) {
        const observer = otherArgs.observer;
        const mockData: boolean = otherArgs.mockData;
        const channel = options.channel;
        let uuid = this._getUuid(options.deviceID);
        if (!uuid && mockData) {
            uuid = "test_device";
        }
        if (observer) {
            this.http.delete(this.getChannelUrl(uuid) + channel, this.httpOptions)
                .pipe(
                    catchError((error: HttpErrorResponse) => this.handleError(error))
                )
                .subscribe(res => {
                    if (observer) {
                        observer.next(res);
                    }
                });
        }
    }
    _send(options: any = {}, otherArgs: any = {}) {
        const observer = otherArgs.observer;
        const mockData: boolean = otherArgs.mockData;
        const apiKey = otherArgs.apiKey;
        if (!apiKey) {
            observer.error("Push notifications are not enabled in the project");
            return;
        }
        const channel = options.channel;
        let uuid = this._getUuid(options.deviceID);
        if (!uuid && mockData) {
            uuid = "test_device";
        }
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                "x-appery-push-api-key": apiKey
            })
        };
        if (observer) {
            this.http.post(this.getSendPushUrl(), options, httpOptions)
                .pipe(
                    catchError((error: HttpErrorResponse) => this.handleError(error))
                )
                .subscribe(res => {
                    if (observer) {
                        observer.next(res);
                    }
                });
        }
    }
    private handleError(error: HttpErrorResponse, observer = undefined) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error('An error occurred:', error.error.message);
        } else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            console.error('Backend returned code ' + error.status + ', body was: ' + error.error);
        }
        if (observer) {
            observer.error(error);
        } else {
            this._execCallbacks(ERROR, error);
        }
        return throwError('Something bad happened; please try again later.');
    }
    createChannel(options: any): Promise < any > {
        return this.push.createChannel(options);
    }
    deleteChannel(id?: string): Promise < any > {
        return this.push.deleteChannel(id);
    }
    listChannels(): Promise < any > {
        return this.push.listChannels();
    }
    setApplicationIconBadgeNumber(count) {
        if (this.pushObject) {
            return this.pushObject.setApplicationIconBadgeNumber(count);
        } else {
            return Promise.reject();
        }
    }
    getApplicationIconBadgeNumber() {
        if (this.pushObject) {
            return this.pushObject.getApplicationIconBadgeNumber();
        } else {
            return Promise.reject();
        }
    }
    clearAllNotifications() {
        if (this.pushObject) {
            return this.pushObject.clearAllNotifications();
        } else {
            return Promise.reject();
        }
    }
    getPlatform(): string {
        return this.device.platform;
    }
    getDeviceUuid(): string {
        return this._getUuid();
    }
    getPushInstance() {
        return this.pushObject;
    }
    /**
     * iOS only
     * Tells the OS that you are done processing a background push notification.
     * successHandler gets called when background push processing is successfully completed.
     * @param [id]
     */
    finish(id?: string): Promise < any > {
        return this.pushObject.finish(id);
    }
};